library(openxlsx)
library(lubridate)
library(forecast)
library(TTR) # SMA() function

data <- read.xlsx("Session 2 - workshop data.xlsx")

head(data)

# separate out by vehicle type 
cars_data <- subset(data, vehicle_type == "Cars", select = c(month, number))
rental_cars_data <- subset(data, vehicle_type == "Rental Cars", select = c(month, number))
taxi_data <- subset(data, vehicle_type == "Taxi", select = c(month, number))
buses_data <- subset(data, vehicle_type == "Buses", select = c(month, number))
motorcycles_data <- subset(data, vehicle_type == "Motorcycles", select = c(month, number))
others_data <- subset(data, vehicle_type == "Goods & Other Vehicles", select = c(month, number))

# cars time series object
cars_ts <- ts(cars_data$number, frequency = 12, start = c(2012,1), end = c(2017, 7))
plot.ts(cars_ts)

# rental cars time series
rental_cars_ts <- ts(rental_cars_data$number, frequency = 12, start = c(2012,1), end = c(2017, 7))
plot.ts(rental_cars_ts)

# taxis time series
taxi_ts <- ts(taxi_data$number, frequency = 12, start = c(2012,1), end = c(2018, 2))
plot.ts(taxi_ts)

# buses time series
buses_ts <- ts(buses_data$number, frequency = 12, start = c(2012,1), end = c(2018, 2))
plot.ts(buses_ts)

# motorcycles time series
motorcycles_ts <- ts(motorcycles_data$number, frequency = 12, start = c(2012,1), end = c(2017, 7))
plot.ts(motorcycles_ts)

# others time series
others_ts <- ts(others_data$number, frequency = 12, start = c(2012,1), end = c(2018, 2))
plot.ts(others_ts)

#####################################################
# Smoothing Method 1 - Simple Exponential Smoothing #
#####################################################

# cars
car_forecasts <- HoltWinters(cars_ts, beta=FALSE, gamma=FALSE) # beta - false => exponential smoothing
car_forecasts
plot(car_forecasts, main = "Simple Exponential Smoothing Fit")
car_forecasts$fitted
car_forecasts$SSE

car_forecasts2 <- forecast(car_forecasts, h=12)
car_forecasts2 
plot(car_forecasts2, main = "Simple Exponential Smoothing Forecast")

# taxis
taxi_forecasts <- HoltWinters(taxi_ts, beta=FALSE, gamma=FALSE)
taxi_forecasts
taxi_forecasts$fitted

taxi_forecasts2 <- forecast(taxi_forecasts, h=12)
taxi_forecasts2 
plot(taxi_forecasts2)

# rental cars

# buses
buses_forecasts <- HoltWinters(buses_ts, beta=FALSE, gamma=FALSE)
buses_forecasts
plot(buses_forecasts, main = "Simple Exponential Smoothing Fit")
buses_forecasts$fitted
buses_forecasts$SSE


buses_forecasts2 <- forecast(buses_forecasts, h=12)
buses_forecasts2 
plot(buses_forecasts2, main = "Simple Exponential Smoothing Forecast")

# motorcycles
motorcycles_forecasts <- HoltWinters(motorcycles_ts, beta=FALSE, gamma=FALSE)
motorcycles_forecasts
plot(motorcycles_forecasts, main = "Simple Exponential Smoothing Fit")
motorcycles_forecasts$fitted

motorcycles_forecasts2 <- forecast(motorcycles_forecasts, h=12)
motorcycles_forecasts2 
plot(motorcycles_forecasts2, main = "Simple Exponential Smoothing Forecast")

# others

###################################################
# Smoothing Method 2 - Holt Exponential Smoothing #
###################################################

# cars 
car_forecasts <- HoltWinters(cars_ts, gamma=FALSE) # gamma - false => non-seasonal 
car_forecasts
plot(car_forecasts, main = "Holt Exponential Smoothing Fit")
car_forecasts$fitted
car_forecasts$SSE

car_forecasts2 <- forecast(car_forecasts, h=12)
car_forecasts2 
plot(car_forecasts2, main = "Holt Exponential Smoothing Forecast")

# taxis
taxi_forecasts <- HoltWinters(taxi_ts, gamma=FALSE)
taxi_forecasts
taxi_forecasts$fitted

taxi_forecasts2 <- forecast(taxi_forecasts, h=12)
taxi_forecasts2 
plot(taxi_forecasts2)

# rental cars

# buses
buses_forecasts <- HoltWinters(buses_ts, gamma=FALSE)
buses_forecasts
plot(buses_forecasts, main = "Holt Exponential Smoothing Fit")
buses_forecasts$fitted
buses_forecasts$SSE

buses_forecasts2 <- forecast(buses_forecasts, h=12)
buses_forecasts2 
plot(buses_forecasts2, main = "Holt Exponential Smoothing Forecast")

# motorcycles

# others

###########################################################
# Smoothing Method 3 - Holt-Winters Exponential Smoothing #
###########################################################

# cars 
car_forecasts <- HoltWinters(cars_ts) # gamma - false => non-seasonal 
car_forecasts
plot(car_forecasts, main = "Holt-Winters Exponential Smoothing Fit")
car_forecasts$fitted
car_forecasts$SSE

car_forecasts2 <- forecast(car_forecasts, h=12)
car_forecasts2 
plot(car_forecasts2, main = "Holt-Winters Exponential Smoothing Forecast")

# taxis
taxi_forecasts <- HoltWinters(taxi_ts)
taxi_forecasts
taxi_forecasts$fitted

taxi_forecasts2 <- forecast(taxi_forecasts, h=12)
taxi_forecasts2 
plot(taxi_forecasts2)


# rental cars

# buses
buses_forecasts <- HoltWinters(buses_ts)
buses_forecasts
plot(buses_forecasts, main = "Holt-Winters Exponential Smoothing Fit")
buses_forecasts$fitted
buses_forecasts$SSE

buses_forecasts2 <- forecast(buses_forecasts, h=12)
buses_forecasts2 
plot(buses_forecasts2, main = "Holt-Winters Exponential Smoothing Forecast")

# motorcycles

# others
